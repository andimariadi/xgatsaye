-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 07, 2022 at 09:33 AM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `berkala_bkd`
--

-- --------------------------------------------------------

--
-- Table structure for table `ajuan_usul_berkala`
--

CREATE TABLE `ajuan_usul_berkala` (
  `nip` varchar(18) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(100) DEFAULT 'Menunggu Diterima'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `berkas_ajuan_usul_berkala`
--

CREATE TABLE `berkas_ajuan_usul_berkala` (
  `nip` varchar(18) NOT NULL,
  `file_path_form` text NOT NULL,
  `file_path_sk_berkala` text NOT NULL,
  `file_path_sk_pangkat` text NOT NULL,
  `file_path_sk_jabatan` text NOT NULL,
  `form` varchar(10) NOT NULL DEFAULT 'false',
  `sk_berkala_terakhir` varchar(10) NOT NULL DEFAULT 'false',
  `sk_pangkat_terakhir` varchar(10) NOT NULL DEFAULT 'false',
  `sk_pemangku_jabatan` varchar(10) NOT NULL DEFAULT 'false',
  `keterangan` varchar(100) DEFAULT 'Menunggu Diterima',
  `admin` varchar(20) NOT NULL DEFAULT 'PROSES',
  `pimpinan` varchar(20) NOT NULL DEFAULT 'PROSES'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `data_pegawai`
--

CREATE TABLE `data_pegawai` (
  `nip` varchar(18) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gelar_depan` varchar(20) DEFAULT NULL,
  `gelar_belakang` varchar(20) DEFAULT NULL,
  `tempat_lahir` text,
  `tanggal_lahir` varchar(10) DEFAULT NULL,
  `gol_awal_cpns` varchar(10) DEFAULT NULL,
  `tmt_cpns` varchar(10) DEFAULT NULL,
  `tmt_pns` varchar(10) DEFAULT NULL,
  `jenis_kelamin` varchar(1) DEFAULT NULL,
  `gol_akhir` varchar(10) DEFAULT NULL,
  `tmt_gol_akhir` varchar(10) DEFAULT NULL,
  `thn_masa_kerja` varchar(5) DEFAULT NULL,
  `bln_masa_kerja` varchar(5) DEFAULT NULL,
  `tmt_jabatan_struktural` varchar(10) DEFAULT NULL,
  `nama_jabatan_struktural` text,
  `tmt_jabatan_fungsional_tertentu` varchar(10) DEFAULT NULL,
  `nama_jabatan_fungsional_tertentu` text,
  `nama_jabatan_fungsional_umum` text,
  `unit_kerja` varchar(150) DEFAULT NULL,
  `unit_kerja_induk` varchar(100) DEFAULT NULL,
  `no_hp` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_pegawai`
--

INSERT INTO `data_pegawai` (`nip`, `nama`, `gelar_depan`, `gelar_belakang`, `tempat_lahir`, `tanggal_lahir`, `gol_awal_cpns`, `tmt_cpns`, `tmt_pns`, `jenis_kelamin`, `gol_akhir`, `tmt_gol_akhir`, `thn_masa_kerja`, `bln_masa_kerja`, `tmt_jabatan_struktural`, `nama_jabatan_struktural`, `tmt_jabatan_fungsional_tertentu`, `nama_jabatan_fungsional_tertentu`, `nama_jabatan_fungsional_umum`, `unit_kerja`, `unit_kerja_induk`, `no_hp`) VALUES
('195910041988042001', 'RAHIMAH', '', '', 'TAPIN', '1959-10-04', 'II/a', '1988-04-01', '1989-08-01', 'P', 'IV/a', '2009-04-01', '22', '0', '', '', '2009-04-01', 'Guru Pembina', '', 'SD NEGERI HARAPAN MASA 2', 'DINAS PENDIDIKAN', '085754474325'),
('196209231986031010', 'ANDIANA KRISTANTO', '', 'SP', 'SRAGEN', '1962-09-23', 'II/a', '1986-03-01', '1987-10-01', 'P', 'IV/b', '2014-04-01', '26', '3', '', '', '2017-01-03', 'Penyuluh Pertanian Madya / Ahli Madya', '', 'POKJAFUNG', 'DINAS PERTANIAN', '081212127182'),
('196304191985031007', 'SYAIFUL BAHRIN NOOR', 'Drs. H', '', 'BANJAR', '1963-04-19', 'II/a', '1985-03-01', '1986-12-01', 'L', 'IV/c', '2013-04-01', '32', '0', '2020-03-13', 'Kepala BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA', '', '', '', 'BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA', 'BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA', '081296782912'),
('196305301996031001', 'FATHUR RAHMAN', 'H.', 'SH, MH', 'HULU SUNGAI SELATAN', '1963-03-05', 'III/a', '1963-05-30', '1987-03-01', 'L', 'IV/b', '2008-01-04', '18', '10', '', 'Kepala BIDANG PRASARANA', '', 'Guru Pembina', '', 'BIDANG PRASARANA', 'DINAS PERHUBUNGAN', ''),
('196306141989021005', 'NORHAIDI', '', 'S.Pd', 'TAPIN', '1963-06-14', 'II/c', '1989-02-01', '1990-12-01', 'L', 'IV/a', '2014-04-01', '24', '2', '2017-06-20', 'Kepala BIDANG PRASARANA', '', '', '', 'BIDANG PRASARANA', 'DINAS PERHUBUNGAN', '08196578667'),
('196306201986032011', 'YUNI LESTARI', '', 'S.AP', 'TAPIN', '1963-06-20', 'II/a', '1986-03-01', '1987-10-01', 'P', 'III/d', '2016-10-01', '28', '10', '2016-12-27', 'Kepala SEKSI LAYANAN OTOMASI DAN KERJASAMA PERPUSTAKAAN', '', '', '', 'SEKSI LAYANAN OTOMASI DAN KERJASAMA PERPUSTAKAAN', 'DINAS PERPUSTAKAAN DAN KEARSIPAN', '081278929028'),
('196307191986032008', 'NURHANIAH', '', 'A.Md.Kes', 'TAPIN', '1963-07-19', 'II/a', '1986-03-01', '1987-05-01', 'P', 'III/d', '2011-04-01', '22', '1', '', '', '2009-10-01', 'Sanitarian Penyelia', '', 'PUSKESMAS TAPIN UTARA', 'DINAS KESEHATAN', '087812345678'),
('196308011990102001', 'SITI AMINAH', '', '', 'TAPIN', '1963-08-01', 'II/a', '1990-10-01', '1991-12-01', 'P', 'III/d', '2018-04-01', '28', '10', '2016-12-27', 'Kepala SUB BAGIAN TATA USAHA KEPEGAWAIAN DAN PERLENGKAPAN', '', '', '', 'SUB BAGIAN TATA USAHA KEPEGAWAIAN DAN PERLENGKAPAN', 'SEKRETARIAT DPRD', '081236782910'),
('196308081982072002', 'SITI HADIJAH', '', '', 'TAPIN', '1963-08-08', 'II/a', '1982-07-01', '1985-03-01', 'P', 'IV/a', '2006-04-01', '20', '9', '', '', '2006-04-01', 'Guru Pembina', '', 'SD NEGERI HARAPAN MASA 2', 'DINAS PENDIDIKAN', '081945757857'),
('196308111989031012', 'ARIFIN WIJAYA', '', '', 'TAPIN', '1963-08-11', 'II/a', '1989-03-01', '1990-10-01', 'L', 'III/b', '2008-04-01', '16', '1', '', '', '', '', 'PEMELIHARA JALAN', 'KASUBAG TATA USAHA', 'DINAS PEKERJAAN UMUM DAN PENATAAN RUANG', '085746746968'),
('196310231985031006', 'JAYADI MAHMUD', 'Drs.', '', 'HULU SUNGAI SELATAN', '1963-10-23', 'II/a', '1985-03-01', '1986-04-01', 'L', 'IV/b', '2006-04-01', '26', '8', '2016-12-27', 'Kepala BIDANG REHABILITASI DAN REKONSTRUKSI', '', '', '', 'BIDANG REHABILITASI DAN REKONSTRUKSI', 'BADAN PENANGGULANGAN BENCANA DAERAH', '081356858578'),
('196311101994031011', 'RUSLIA NAJIB', '', 'S.Pt', 'TAPIN', '1963-11-10', 'II/a', '1994-03-01', '1995-08-01', 'L', 'III/d', '2018-04-01', '32', '0', '2016-12-27', 'Kepala SEKSI PENGOPERASIAN DAN PERAWATAN PRASARANA', '', '', '', 'SEKSI PENGOPERASIAN DAN PERAWATAN PRASARANA', 'DINAS PERHUBUNGAN', '081257733748'),
('196311181984011001', 'IBRAHIM ISTAR', '', '', 'TAPIN', '1963-11-18', 'II/a', '1984-01-01', '1987-10-01', 'L', 'III/d', '2007-10-01', '18', '9', '', '', '2010-01-01', 'Perawat Penyelia', '', 'PUSKESMAS HATUNGUN', 'DINAS KESEHATAN', '087835689645'),
('196311261984122007', 'MAHRITTA', 'Hj.', 'S.Pd', 'BANJAR', '1963-11-26', 'II/a', '1984-12-01', '1986-07-01', 'P', 'IV/b', '2019-10-01', '2', '7', '', '', '2019-10-01', 'Guru Madya / Ahli Madya', '', 'SMP NEGERI 2 RANTAU', 'DINAS PENDIDIKAN', '081826783728'),
('196312062007011010', 'AGUNG SETYAWAN', '', '', 'KLATEN', '1963-12-06', 'II/a', '2007-01-01', '2009-05-01', 'L', 'II/d', '2019-04-01', '16', '9', '', '', '', '', 'PENGAWAS JALAN DAN JEMBATAN', 'SEKSI PEMBANGUNAN JALAN DAN JEMBATAN', 'DINAS PEKERJAAN UMUM DAN PENATAAN RUANG', '081756838935'),
('196405251984122004', 'MISRIATUL KIBTIAH', '', '', 'TAPIN', '1964-05-25', 'II/a', '1984-12-01', '1986-06-01', 'P', 'III/b', '2004-04-01', '12', '4', '', '', '', '', 'PENGADMINISTRASI UMUM', 'SEKSI PENCEGAHAN DAN PENGENDALIAN PENYAKIT MENULAR', 'DINAS KESEHATAN', '082356735689'),
('196405301987111001', 'SYAMSUDIN', '', '', 'HULU SUNGAI SELATAN', '1964-05-30', 'II/a', '1987-11-01', '1988-11-01', 'L', 'III/b', '2007-04-01', '16', '9', '', '', '', '', 'OPERATOR ALAT BERAT', 'BIDANG JASA KONSTRUKSI', 'DINAS PEKERJAAN UMUM DAN PENATAAN RUANG', '087785678467'),
('196406031985032010', 'NORSIDAH', '', '', 'TAPIN', '1964-06-03', 'II/a', '1985-03-01', '1986-10-01', 'P', 'IV/a', '2008-10-01', '16', '7', '', '', '2017-03-20', 'Guru Madya / Ahli Madya', '', 'SMP NEGERI 2 BAKARANGAN', 'DINAS PENDIDIKAN', '087745673456'),
('196406101994032005', 'JAHARAM', '', '', 'TAPIN', '1964-06-10', 'II/a', '1994-03-01', '1995-04-01', 'P', 'III/b', '2014-10-01', '15', '7', '', '', '', '', 'VERIFIKATOR KEUANGAN', 'SUB BAGIAN PERENCANAAN DAN KEUANGAN', 'DINAS KESEHATAN', '081274678956'),
('199105022015031004', 'SURYA CANDRA UTAMA', '', 'A.Md', 'BANJARMASIN', '1991-05-02', 'II/c', '2015-03-01', '2016-10-01', 'L', 'II/d', '2019-04-01', '9', '1', '', '', '', '', 'PENGELOLA FORMASI DAN PENGADAAN PEGAWAI', 'SUB BIDANG PENGADAAN DAN PENSIUN', 'BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA', '087814573892'),
('199201162020121002', 'BAYU AJI', '', 'S.Kom', 'NGANJUK', '1992-01-16', 'III/a', '2019-12-01', '2020-12-01', 'L', 'III/a', '2020-01-01', '02', '00', '', '', '', '', 'AHLI PERTAMA - INSTRUKTUR', 'UNIT PELAKSANA TEKNIS BALAI LATIHAN KERJA', 'DINAS TENAGA KERJA', '087845674678'),
('199202082020122008', 'SANTY RAHAYU', '', 'S.E', 'MADIUN', '1992-02-08', 'III/a', '2019-12-01', '2020-12-01', 'P', 'III/a', '2020-12-01', '02', '00', '', '', '', '', 'PENATA KEUANGAN', 'DINAS PERIKANAN', 'DINAS PERIKANAN', '081982939292'),
('199505162019031003', 'DOFI WIJAYA', '', 'A.Md', 'SAMARINDA', '1995-05-16', 'II/c', '2019-03-01', '2020-03-01', 'L', 'III/a', '2019-03-01', '4', '0', '', '', '', '', 'PENGELOLA SISTEM INFORMASI MANAJEMEN KEPEGAWAIAN', 'SUB BIDANG DATA DAN INFORMASI', 'BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA', '081562782718'),
('199506132020122014', 'LIA ARIANI', '', 'S.Pd', 'TAPIN', '1995-06-13', 'III/a', '2019-03-01', '2020-03-01', 'P', 'III/a', '2020-03-01', '6', '0', '', '', '', '', 'AHLI PERTAMA- GURU PENJASORKES', 'SD NEGERI BINUANG 3', 'DINAS PENDIDIKAN', '0818257272821'),
('199510312019032002', 'MARFUAH', '', 'S.Ak', 'TAPIN', '1995-10-31', 'II/c', '2019-03-01', '2020-03-01', 'P', 'III/a', '2020-03-01', '4', '0', '', '', '', '', 'AUDITOR AHLI PERTAMA', 'POKJAFUNG (PENGAWAS PEMERINTAHAN & AUDITOR)', 'INSPEKTORAT', '081912568201');

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi_naik_gaji`
--

CREATE TABLE `notifikasi_naik_gaji` (
  `id` int(25) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nip` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(155) NOT NULL,
  `message` text NOT NULL,
  `pangkat` varchar(10) NOT NULL,
  `masa_jabatan` int(2) NOT NULL,
  `golongan` varchar(100) NOT NULL,
  `gaji_pokok` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi_pensiun`
--

CREATE TABLE `notifikasi_pensiun` (
  `id` int(25) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nip` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(155) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi_usul_berkala`
--

CREATE TABLE `notifikasi_usul_berkala` (
  `id` int(25) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nip` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(155) NOT NULL,
  `kategori_pensiun` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `proses_usul_berkala`
--

CREATE TABLE `proses_usul_berkala` (
  `nip` varchar(18) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` text,
  `kategori` text NOT NULL,
  `masa_jabatan` varchar(30) NOT NULL,
  `bln_masa_jabatan` varchar(2) DEFAULT '00',
  `token` varchar(5) DEFAULT NULL,
  `token_status` varchar(13) NOT NULL DEFAULT 'Belum Dikirim',
  `verifikasi_status` varchar(13) NOT NULL DEFAULT 'Belum Dikirim',
  `pemberkasan_status` varchar(15) DEFAULT 'Belum Mengisi',
  `nomor_sk` text,
  `nomor_sk_lama` text,
  `tanggal_sk` text,
  `tanggal_sk_lama` text,
  `tanggal_tmt` text,
  `tanggal_tmt_lama` text,
  `masa_kerja_lama` text,
  `gaji_pokok` text,
  `gaji_pokok_lama` text,
  `nama_nip` text,
  `pangkat_jabatan` text,
  `tempat_tgl_lahir` text,
  `unit_skpd` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `riwayat_usul_berkala`
--

CREATE TABLE `riwayat_usul_berkala` (
  `id` int(11) NOT NULL,
  `tanggal_usul` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `tanggal_terbit` date DEFAULT NULL,
  `nip` varchar(18) NOT NULL,
  `masa_jabatan` text,
  `bln_masa_jabatan` varchar(2) DEFAULT NULL,
  `kategori` text NOT NULL,
  `nomor_sk` text,
  `tanggal_sk` text,
  `nama_nip` text,
  `tempat_tgl_lahir` text,
  `pangkat_jabatan` text,
  `unit_skpd` text,
  `gaji_pokok_lama` text,
  `tanggal_sk_lama` text,
  `nomor_sk_lama` text,
  `tanggal_tmt_lama` text,
  `masa_kerja_lama` text,
  `gaji_pokok` text,
  `tanggal_tmt` text,
  `penerima` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` varchar(50) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `value`) VALUES
('nomor_sk', '0043');

-- --------------------------------------------------------

--
-- Table structure for table `table_gajih`
--

CREATE TABLE `table_gajih` (
  `id` int(3) NOT NULL,
  `pangkat` varchar(5) DEFAULT NULL,
  `masa_jabatan` varchar(2) DEFAULT NULL,
  `golongan` varchar(50) DEFAULT NULL,
  `gaji_pokok` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_gajih`
--

INSERT INTO `table_gajih` (`id`, `pangkat`, `masa_jabatan`, `golongan`, `gaji_pokok`) VALUES
(1, 'Ia', '0', 'Juru Muda', '1.560.800'),
(2, 'Ia', '2', 'Juru Muda', '1.610.000'),
(3, 'Ia', '4', 'Juru Muda', '1.660.700'),
(4, 'Ia', '6', 'Juru Muda', '1.713.000'),
(5, 'Ia', '8', 'Juru Muda', '1.766.900'),
(6, 'Ia', '10', 'Juru Muda', '1.822.600'),
(7, 'Ia', '12', 'Juru Muda', '1.880.000'),
(8, 'Ia', '14', 'Juru Muda', '1.939.200'),
(9, 'Ia', '16', 'Juru Muda', '2.000.300'),
(10, 'Ia', '18', 'Juru Muda', '2.063.300'),
(11, 'Ia', '20', 'Juru Muda', '2.128.300'),
(12, 'Ia', '22', 'Juru Muda', '2.195.300'),
(13, 'Ia', '24', 'Juru Muda', '2.264.400'),
(14, 'Ia', '26', 'Juru Muda', '2.335.800'),
(15, 'Ib', '3', 'Juru Muda TK. I', '1.704.500'),
(16, 'Ib', '5', 'Juru Muda TK. I', '1.758.200'),
(17, 'Ib', '7', 'Juru Muda TK. I', '1.813.600'),
(18, 'Ib', '9', 'Juru Muda TK. I', '1.870.700'),
(19, 'Ib', '11', 'Juru Muda TK. I', '1.929.600'),
(20, 'Ib', '13', 'Juru Muda TK. I', '1.990.400'),
(21, 'Ib', '15', 'Juru Muda TK. I', '2.053.100'),
(22, 'Ib', '17', 'Juru Muda TK. I', '2.117.700'),
(23, 'Ib', '19', 'Juru Muda TK. I', '2.184.400'),
(24, 'Ib', '21', 'Juru Muda TK. I', '2.253.200'),
(25, 'Ib', '23', 'Juru Muda TK. I', '2.324.200'),
(26, 'Ib', '25', 'Juru Muda TK. I', '2.397.400'),
(27, 'Ib', '27', 'Juru Muda TK. I', '2.472.900'),
(28, 'Ic', '3', 'Juru', '1.776.600'),
(29, 'Ic', '5', 'Juru', '1.832.600'),
(30, 'Ic', '7', 'Juru', '1.890.300'),
(31, 'Ic', '9', 'Juru', '1.949.800'),
(32, 'Ic', '11', 'Juru', '2.011.200'),
(33, 'Ic', '13', 'Juru', '2.074.600'),
(34, 'Ic', '15', 'Juru', '2.139.900'),
(35, 'Ic', '17', 'Juru', '2.207.300'),
(36, 'Ic', '19', 'Juru', '2.276.800'),
(37, 'Ic', '21', 'Juru', '2.348.500'),
(38, 'Ic', '23', 'Juru', '2.422.500'),
(39, 'Ic', '25', 'Juru', '2.498.800'),
(40, 'Ic', '27', 'Juru', '2.577.500'),
(41, 'Id', '3', 'Juru TK. I', '1.851.800'),
(42, 'Id', '5', 'Juru TK. I', '1.910.100'),
(43, 'Id', '7', 'Juru TK. I', '1.970.200'),
(44, 'Id', '9', 'Juru TK. I', '2.032.300'),
(45, 'Id', '11', 'Juru TK. I', '2.096.300'),
(46, 'Id', '13', 'Juru TK. I', '2.162.300'),
(47, 'Id', '15', 'Juru TK. I', '2.230.400'),
(48, 'Id', '17', 'Juru TK. I', '2.300.700'),
(49, 'Id', '19', 'Juru TK. I', '2.373.100'),
(50, 'Id', '21', 'Juru TK. I', '2.447.900'),
(51, 'Id', '23', 'Juru TK. I', '2.525.000'),
(52, 'Id', '25', 'Juru TK. I', '2.604.500'),
(53, 'Id', '27', 'Juru TK. I', '2.686.500'),
(54, 'IIa', '0', 'Pengatur Muda', '2.022.200'),
(55, 'IIa', '1', 'Pengatur Muda', '2.054.100'),
(56, 'IIa', '3', 'Pengatur Muda', '2.118.500'),
(57, 'IIa', '5', 'Pengatur Muda', '2.185.500'),
(58, 'IIa', '7', 'Pengatur Muda', '2.254.300'),
(59, 'IIa', '9', 'Pengatur Muda', '2.325.300'),
(60, 'IIa', '11', 'Pengatur Muda', '2.398.600'),
(61, 'IIa', '13', 'Pengatur Muda', '2.474.100'),
(62, 'IIa', '15', 'Pengatur Muda', '2.552.000'),
(63, 'IIa', '17', 'Pengatur Muda', '2.632.400'),
(64, 'IIa', '19', 'Pengatur Muda', '2.715.300'),
(65, 'IIa', '21', 'Pengatur Muda', '1.800.899'),
(66, 'IIa', '23', 'Pengatur Muda', '2.889.100'),
(67, 'IIa', '25', 'Pengatur Muda', '2.980.000'),
(68, 'IIa', '27', 'Pengatur Muda', '3.073.900'),
(69, 'IIa', '29', 'Pengatur Muda', '3.170.700'),
(70, 'IIa', '31', 'Pengatur Muda', '3.270.600'),
(71, 'IIa', '33', 'Pengatur Muda', '3.373.600'),
(72, 'IIb', '3', 'Pengatur Muda TK. I', '2.208.400'),
(73, 'IIb', '5', 'Pengatur Muda TK. I', '2.277.900'),
(74, 'IIb', '7', 'Pengatur Muda TK. I', '2.349.700'),
(75, 'IIb', '9', 'Pengatur Muda TK. I', '2.423.700'),
(76, 'IIb', '11', 'Pengatur Muda TK. I', '2.500.000'),
(77, 'IIb', '13', 'Pengatur Muda TK. I', '2.578.800'),
(78, 'IIb', '15', 'Pengatur Muda TK. I', '2.660.000'),
(79, 'IIb', '17', 'Pengatur Muda TK. I', '2.743.800'),
(80, 'IIb', '19', 'Pengatur Muda TK. I', '2.830.200'),
(81, 'IIb', '21', 'Pengatur Muda TK. I', '2.919.300'),
(82, 'IIb', '23', 'Pengatur Muda TK. I', '3.011.300'),
(83, 'IIb', '25', 'Pengatur Muda TK. I', '3.106.100'),
(84, 'IIb', '27', 'Pengatur Muda TK. I', '3.203.900'),
(85, 'IIb', '29', 'Pengatur Muda TK. I', '3.304.800'),
(86, 'IIb', '31', 'Pengatur Muda TK. I', '3.408.900'),
(87, 'IIb', '33', 'Pengatur Muda TK. I', '3.516.300'),
(88, 'IIc', '3', 'Pengatur', '2.301.800'),
(89, 'IIc', '5', 'Pengatur', '2.374.300'),
(90, 'IIc', '7', 'Pengatur', '2.449.100'),
(91, 'IIc', '9', 'Pengatur', '2.526.200'),
(92, 'IIc', '11', 'Pengatur', '2.605.800'),
(93, 'IIc', '13', 'Pengatur', '2.687.800'),
(94, 'IIc', '15', 'Pengatur', '2.772.500'),
(95, 'IIc', '17', 'Pengatur', '2.859.800'),
(96, 'IIc', '19', 'Pengatur', '2.949.900'),
(97, 'IIc', '21', 'Pengatur', '3.042.800'),
(98, 'IIc', '23', 'Pengatur', '3.138.600'),
(99, 'IIc', '25', 'Pengatur', '3.237.500'),
(100, 'IIc', '27', 'Pengatur', '3.339.400'),
(101, 'IIc', '29', 'Pengatur', '3.444.600'),
(102, 'IIc', '31', 'Pengatur', '3.553.100'),
(103, 'IIc', '33', 'Pengatur', '3.665.000'),
(104, 'IId', '3', 'Pengatur TK. I', '2.399.200'),
(105, 'IId', '5', 'Pengatur TK. I', '2.474.700'),
(106, 'IId', '7', 'Pengatur TK. I', '2.552.700'),
(107, 'IId', '9', 'Pengatur TK. I', '2.633.100'),
(108, 'IId', '11', 'Pengatur TK. I', '2.716.000'),
(109, 'IId', '13', 'Pengatur TK. I', '2.801.500'),
(110, 'IId', '15', 'Pengatur TK. I', '2.889.800'),
(111, 'IId', '17', 'Pengatur TK. I', '2.980.800'),
(112, 'IId', '19', 'Pengatur TK. I', '3.074.700'),
(113, 'IId', '21', 'Pengatur TK. I', '3.171.500'),
(114, 'IId', '23', 'Pengatur TK. I', '3.271.400'),
(115, 'IId', '25', 'Pengatur TK. I', '3.374.400'),
(116, 'IId', '27', 'Pengatur TK. I', '3.480.700'),
(117, 'IId', '29', 'Pengatur TK. I', '3.590.300'),
(118, 'IId', '31', 'Pengatur TK. I', '3.703.400'),
(119, 'IId', '33', 'Pengatur TK. I', '3.820.000'),
(120, 'IIIa', '0', 'Penata Muda', '2.579.400'),
(121, 'IIIa', '2', 'Penata Muda', '2.660.700'),
(122, 'IIIa', '4', 'Penata Muda', '2.744.500'),
(123, 'IIIa', '6', 'Penata Muda', '2.830.900'),
(124, 'IIIa', '8', 'Penata Muda', '2.920.100'),
(125, 'IIIa', '10', 'Penata Muda', '3.012.000'),
(126, 'IIIa', '12', 'Penata Muda', '3.106.900'),
(127, 'IIIa', '14', 'Penata Muda', '3.204.700'),
(128, 'IIIa', '16', 'Penata Muda', '3.305.700'),
(129, 'IIIa', '18', 'Penata Muda', '3.409.800'),
(130, 'IIIa', '20', 'Penata Muda', '3.517.200'),
(131, 'IIIa', '22', 'Penata Muda', '3.627.900'),
(132, 'IIIa', '24', 'Penata Muda', '3.742.200'),
(133, 'IIIa', '26', 'Penata Muda', '3.860.100'),
(134, 'IIIa', '28', 'Penata Muda', '3.981.600'),
(135, 'IIIa', '30', 'Penata Muda', '4.107.000'),
(136, 'IIIa', '32', 'Penata Muda', '4.236.400'),
(137, 'IIIb', '0', 'Penata Muda TK. I', '2.688.500'),
(138, 'IIIb', '2', 'Penata Muda TK. I', '2.773.200'),
(139, 'IIIb', '4', 'Penata Muda TK. I', '2.860.500'),
(140, 'IIIb', '6', 'Penata Muda TK. I', '2.950.600'),
(141, 'IIIb', '8', 'Penata Muda TK. I', '3.043.600'),
(142, 'IIIb', '10', 'Penata Muda TK. I', '3.139.400'),
(143, 'IIIb', '12', 'Penata Muda TK. I', '3.238.300'),
(144, 'IIIb', '14', 'Penata Muda TK. I', '3.340.300'),
(145, 'IIIb', '16', 'Penata Muda TK. I', '3.445.500'),
(146, 'IIIb', '18', 'Penata Muda TK. I', '3.554.000'),
(147, 'IIIb', '20', 'Penata Muda TK. I', '3.665.900'),
(148, 'IIIb', '22', 'Penata Muda TK. I', '3.781.400'),
(149, 'IIIb', '24', 'Penata Muda TK. I', '3.900.500'),
(150, 'IIIb', '26', 'Penata Muda TK. I', '4.023.300'),
(151, 'IIIb', '28', 'Penata Muda TK. I', '4.150.100'),
(152, 'IIIb', '30', 'Penata Muda TK. I', '4.280.800'),
(153, 'IIIb', '32', 'Penata Muda TK. I', '4.415.600'),
(154, 'IIIc', '0', 'Penata', '2.802.300'),
(155, 'IIIc', '2', 'Penata', '2.890.500'),
(156, 'IIIc', '4', 'Penata', '2.981.500'),
(157, 'IIIc', '6', 'Penata', '3.075.500'),
(158, 'IIIc', '8', 'Penata', '3.172.300'),
(159, 'IIIc', '10', 'Penata', '3.272.200'),
(160, 'IIIc', '12', 'Penata', '3.375.300'),
(161, 'IIIc', '14', 'Penata', '3.481.600'),
(162, 'IIIc', '16', 'Penata', '3.591.200'),
(163, 'IIIc', '18', 'Penata', '3.704.300'),
(164, 'IIIc', '20', 'Penata', '3.821.000'),
(165, 'IIIc', '22', 'Penata', '3.941.400'),
(166, 'IIIc', '24', 'Penata', '4.065.500'),
(167, 'IIIc', '26', 'Penata', '4.193.500'),
(168, 'IIIc', '28', 'Penata', '4.325.600'),
(169, 'IIIc', '30', 'Penata', '4.461.800'),
(170, 'IIIc', '32', 'Penata', '4.602.400'),
(171, 'IIId', '0', 'Penata TK. I', '2.920.800'),
(172, 'IIId', '2', 'Penata TK. I', '3.012.800'),
(173, 'IIId', '4', 'Penata TK. I', '3.107.700'),
(174, 'IIId', '6', 'Penata TK. I', '3.205.500'),
(175, 'IIId', '8', 'Penata TK. I', '3.306.500'),
(176, 'IIId', '10', 'Penata TK. I', '3.410.600'),
(177, 'IIId', '12', 'Penata TK. I', '3.518.100'),
(178, 'IIId', '14', 'Penata TK. I', '3.628.900'),
(179, 'IIId', '16', 'Penata TK. I', '3.743.100'),
(180, 'IIId', '18', 'Penata TK. I', '3.861.000'),
(181, 'IIId', '20', 'Penata TK. I', '3.982.600'),
(182, 'IIId', '22', 'Penata TK. I', '4.108.100'),
(183, 'IIId', '24', 'Penata TK. I', '4.237.500'),
(184, 'IIId', '26', 'Penata TK. I', '4.370.900'),
(185, 'IIId', '28', 'Penata TK. I', '4.508.600'),
(186, 'IIId', '30', 'Penata TK. I', '4.650.600'),
(187, 'IIId', '32', 'Penata TK. I', '4.797.000'),
(188, 'IVa', '0', 'Pembina', '3.044.300'),
(189, 'IVa', '2', 'Pembina', '3.140.200'),
(190, 'IVa', '4', 'Pembina', '3.239.100'),
(191, 'IVa', '6', 'Pembina', '3.341.100'),
(192, 'IVa', '8', 'Pembina', '3.446.400'),
(193, 'IVa', '10', 'Pembina', '3.554.900'),
(194, 'IVa', '12', 'Pembina', '3.666.900'),
(195, 'IVa', '14', 'Pembina', '3.782.400'),
(196, 'IVa', '16', 'Pembina', '3.901.500'),
(197, 'IVa', '18', 'Pembina', '4.024.400'),
(198, 'IVa', '20', 'Pembina', '4.151.100'),
(199, 'IVa', '22', 'Pembina', '4.281.800'),
(200, 'IVa', '24', 'Pembina', '4.416.700'),
(201, 'IVa', '26', 'Pembina', '4.555.800'),
(202, 'IVa', '28', 'Pembina', '4.699.300'),
(203, 'IVa', '30', 'Pembina', '4.847.300'),
(204, 'IVa', '32', 'Pembina', '5.000.000'),
(205, 'IVb', '0', 'Pembina TK. I', '3.173.100'),
(206, 'IVb', '2', 'Pembina TK. I', '3.273.100'),
(207, 'IVb', '4', 'Pembina TK. I', '3.376.100'),
(208, 'IVb', '6', 'Pembina TK. I', '3.482.500'),
(209, 'IVb', '8', 'Pembina TK. I', '3.592.100'),
(210, 'IVb', '10', 'Pembina TK. I', '3.705.300'),
(211, 'IVb', '12', 'Pembina TK. I', '3.822.000'),
(212, 'IVb', '14', 'Pembina TK. I', '3.942.400'),
(213, 'IVb', '16', 'Pembina TK. I', '4.066.500'),
(214, 'IVb', '18', 'Pembina TK. I', '4.194.600'),
(215, 'IVb', '20', 'Pembina TK. I', '4.326.700'),
(216, 'IVb', '22', 'Pembina TK. I', '4.463.000'),
(217, 'IVb', '24', 'Pembina TK. I', '4.603.500'),
(218, 'IVb', '26', 'Pembina TK. I', '4.748.500'),
(219, 'IVb', '28', 'Pembina TK. I', '4.898.100'),
(220, 'IVb', '30', 'Pembina TK. I', '5.052.300'),
(221, 'IVb', '32', 'Pembina TK. I', '5.211.500'),
(222, 'IVc', '0', 'Pembina Utama Muda', '3.307.300'),
(223, 'IVc', '2', 'Pembina Utama Muda', '3.411.500'),
(224, 'IVc', '4', 'Pembina Utama Muda', '3.518.900'),
(225, 'IVc', '6', 'Pembina Utama Muda', '3.629.800'),
(226, 'IVc', '8', 'Pembina Utama Muda', '3.744.100'),
(227, 'IVc', '10', 'Pembina Utama Muda', '3.862.000'),
(228, 'IVc', '12', 'Pembina Utama Muda', '3.983.600'),
(229, 'IVc', '14', 'Pembina Utama Muda', '4.109.100'),
(230, 'IVc', '16', 'Pembina Utama Muda', '4.238.500'),
(231, 'IVc', '18', 'Pembina Utama Muda', '4.372.000'),
(232, 'IVc', '20', 'Pembina Utama Muda', '4.509.700'),
(233, 'IVc', '22', 'Pembina Utama Muda', '4.651.800'),
(234, 'IVc', '24', 'Pembina Utama Muda', '4.798.300'),
(235, 'IVc', '26', 'Pembina Utama Muda', '4.949.400'),
(236, 'IVc', '28', 'Pembina Utama Muda', '5.105.300'),
(237, 'IVc', '30', 'Pembina Utama Muda', '5.266.100'),
(238, 'IVc', '32', 'Pembina Utama Muda', '5.431.900'),
(239, 'IVd', '0', 'Pembina Utama Madya', '3.447.200'),
(240, 'IVd', '2', 'Pembina Utama Madya', '3.555.800'),
(241, 'IVd', '4', 'Pembina Utama Madya', '3.667.800'),
(242, 'IVd', '6', 'Pembina Utama Madya', '3.783.300'),
(243, 'IVd', '8', 'Pembina Utama Madya', '3.902.500'),
(244, 'IVd', '10', 'Pembina Utama Madya', '4.025.400'),
(245, 'IVd', '12', 'Pembina Utama Madya', '4.152.200'),
(246, 'IVd', '14', 'Pembina Utama Madya', '4.282.900'),
(247, 'IVd', '16', 'Pembina Utama Madya', '4.417.800'),
(248, 'IVd', '18', 'Pembina Utama Madya', '4.557.000'),
(249, 'IVd', '20', 'Pembina Utama Madya', '4.700.500'),
(250, 'IVd', '22', 'Pembina Utama Madya', '4.848.500'),
(251, 'IVd', '24', 'Pembina Utama Madya', '5.001.200'),
(252, 'IVd', '26', 'Pembina Utama Madya', '5.158.700'),
(253, 'IVd', '28', 'Pembina Utama Madya', '5.321.200'),
(254, 'IVd', '30', 'Pembina Utama Madya', '5.488.800'),
(255, 'IVd', '32', 'Pembina Utama Madya', '5.661.700'),
(256, 'IVe', '0', 'Pembina Utama', '3.593.100'),
(257, 'IVe', '2', 'Pembina Utama', '3.706.200'),
(258, 'IVe', '4', 'Pembina Utama', '3.822.900'),
(259, 'IVe', '6', 'Pembina Utama', '3.943.300'),
(260, 'IVe', '8', 'Pembina Utama', '4.067.500'),
(261, 'IVe', '10', 'Pembina Utama', '4.195.700'),
(262, 'IVe', '12', 'Pembina Utama', '4.327.800'),
(263, 'IVe', '14', 'Pembina Utama', '4.464.100'),
(264, 'IVe', '16', 'Pembina Utama', '4.604.700'),
(265, 'IVe', '18', 'Pembina Utama', '4.749.700'),
(266, 'IVe', '20', 'Pembina Utama', '4.899.300'),
(267, 'IVe', '22', 'Pembina Utama', '5.053.600'),
(268, 'IVe', '24', 'Pembina Utama', '5.212.800'),
(269, 'IVe', '26', 'Pembina Utama', '5.377.000'),
(270, 'IVe', '28', 'Pembina Utama', '5.546.300'),
(271, 'IVe', '30', 'Pembina Utama', '5.721.000'),
(272, 'IVe', '32', 'Pembina Utama', '5.901.200');

-- --------------------------------------------------------

--
-- Table structure for table `table_pangkat`
--

CREATE TABLE `table_pangkat` (
  `id` int(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nip` varchar(20) NOT NULL,
  `golongan_pangkat_tujuan` varchar(5) NOT NULL,
  `file_path_sk_kenaikan_pangkat_terakhir` text NOT NULL,
  `file_path_fc_sk_cpns_pns` text NOT NULL,
  `file_path_fc_skp` text NOT NULL,
  `file_path_fc_kp` text NOT NULL,
  `sk_kenaikan_pangkat_terakhir` varchar(10) NOT NULL DEFAULT 'false',
  `fc_sk_cpns_pns` varchar(10) NOT NULL DEFAULT 'false',
  `fc_skp` varchar(10) NOT NULL DEFAULT 'false',
  `fc_kp` varchar(10) NOT NULL DEFAULT 'false',
  `admin` varchar(20) NOT NULL DEFAULT 'PROSES',
  `pimpinan` varchar(20) NOT NULL DEFAULT 'PROSES'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `table_pensiun`
--

CREATE TABLE `table_pensiun` (
  `id` int(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nip` varchar(20) NOT NULL,
  `tmt_terakhir_jabatan` date NOT NULL,
  `tanggal_pensiun` date NOT NULL,
  `kategori_pensiun` text NOT NULL,
  `file_path_spp` text NOT NULL,
  `file_path_sk` text NOT NULL,
  `file_path_ktp` text NOT NULL,
  `file_path_foto` text NOT NULL,
  `spp` varchar(10) NOT NULL DEFAULT 'false',
  `fc_sk_cpns_pns` varchar(10) NOT NULL DEFAULT 'false',
  `fc_ktp` varchar(10) NOT NULL DEFAULT 'false',
  `foto` varchar(10) NOT NULL DEFAULT 'false',
  `admin` varchar(20) NOT NULL DEFAULT 'PROSES',
  `pimpinan` varchar(20) NOT NULL DEFAULT 'PROSES'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `verifikator_berkala`
--

CREATE TABLE `verifikator_berkala` (
  `username` varchar(20) NOT NULL,
  `nama` text NOT NULL,
  `password` text NOT NULL,
  `level` text,
  `skpd` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `verifikator_berkala`
--

INSERT INTO `verifikator_berkala` (`username`, `nama`, `password`, `level`, `skpd`, `email`) VALUES
('admin', 'admin', '$2y$10$KKHENzOP.YBWXGFwHFX4cOG1YJH2z.yMSwmglfVjPGRoJcQ.aq7pi', 'admin', NULL, 'mbie.oby@gmail.com'),
('BAPELITBANG', 'Badan Perencanaan Pembangunan, Penelitian dan Pengembangan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'BADAN PERENCANAAN PEMBANGUNAN, PENELITIAN DAN PENGEMBANGAN', 'mbie.oby@gmail.com'),
('BKPSDM', 'Badan Kepegawaian dan Pengembangan Sumberdaya Manusia', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA', 'mbie.oby@gmail.com'),
('BPBD', 'Badan Penanggulangan Bencana Daerah', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'BADAN PENANGGULANGAN BENCANA DAERAH', 'mbie.oby@gmail.com'),
('BPKAD', 'Badan Pengelolaan Keuangan dan Aset Daerah', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'BADAN KEUANGAN DAN ASET DAERAH', 'mbie.oby@gmail.com'),
('BPPRD', 'Badan Pengelolaan Pajak dan Retribusi Daerah', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'BADAN PENGELOLAAN PAJAK DAN RETRIBUSI DAERAH	\r\n', 'mbie.oby@gmail.com'),
('dinkes', 'Dinas Kesehatan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS KESEHATAN', 'mbie.oby@gmail.com'),
('Dinsos', 'Dinas Sosial', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS SOSIAL', 'mbie.oby@gmail.com'),
('DISBUDPAR', 'Dinas Kebudayaan Dan Pariwisata', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS KEBUDAYAAN DAN PARIWISATA', 'mbie.oby@gmail.com'),
('Disdag', 'Dinas Perdagangan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PERDAGANGAN', 'mbie.oby@gmail.com'),
('disdik', 'Dinas Pendidikan', '$2y$10$H8WHVATZkr3TdztvS9vzo.nbyQU2ER5S7KiYCgXQURAn/O2tiwICm', 'skpd', 'DINAS PENDIDIKAN', 'mbie.oby@gmail.com'),
('Disdukcapil', 'Dinas Kependudukan dan Pencatatan Sipil', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL', 'mbie.oby@gmail.com'),
('DISHUB', 'Dinas Perhubungan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PERHUBUNGAN', 'mbie.oby@gmail.com'),
('DISKAN', 'Dinas Perikanan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PERIKANAN', 'mbie.oby@gmail.com'),
('DISKOMINFO', 'Dinas Komunikasi Dan Informatika', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS KOMUNIKASI DAN INFORMATIKA', 'mbie.oby@gmail.com'),
('DISNAKER', 'Dinas Tenaga Kerja', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS TENAGA KERJA', 'mbie.oby@gmail.com'),
('DISPERIN', 'Dinas Perindustrian', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PERINDUSTRIAN', 'mbie.oby@gmail.com'),
('DISPERKIMTAN', 'Dinas Perumahan, Kawasan Permukiman dan Pertanahan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PERUMAHAN, KAWASAN PEMUKIMAN DAN PERTANAHAN', 'mbie.oby@gmail.com'),
('Dispertan', 'Dinas Pertanian', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PERTANIAN', 'mbie.oby@gmail.com'),
('Dispora', 'Dinas Kepemudaan Dan Olahraga', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PEMUDA DAN OLAHRAGA', 'mbie.oby@gmail.com'),
('dispustarsip', 'Dinas Perpustakaan Dan Kearsipan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PERPUSTAKAAN DAN KEARSIPAN', 'mbie.oby@gmail.com'),
('DKP', 'Dinas Ketahanan Pangan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS KETAHANAN PANGAN', 'mbie.oby@gmail.com'),
('DLH', 'Dinas Lingkungan Hidup', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS LINGKUNGAN HIDUP', 'mbie.oby@gmail.com'),
('DP3A', 'Dinas Pemberdayaan Perempuan Dan Perlindungan Anak', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PEMBERDAYAAN PEREMPUAN DAN PERLINDUNGAN ANAK', 'mbie.oby@gmail.com'),
('DPMD', 'Dinas Pemberdayaan Masyarakat Dan Desa', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PEMBERDAYAAN MASYARAKAT DAN DESA', 'mbie.oby@gmail.com'),
('DPMPTSP', 'Dinas Penanaman Modal Dan Pelayanan Terpadu Satu Pintu', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PENANAMAN MODAL DAN PELAYANAN TERPADU SATU PINTU', 'mbie.oby@gmail.com'),
('DPPKB', 'Dinas Pengendalian Penduduk Dan Keluarga Berencana', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PENGENDALIAN PENDUDUK DAN KELUARGA BERENCANA', 'mbie.oby@gmail.com'),
('DPRD', 'Sekretariat DPRD', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'SEKRETARIAT DPRD', 'mbie.oby@gmail.com'),
('Inspektorat', 'Inspektorat', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'INSPEKTORAT', 'mbie.oby@gmail.com'),
('KEC.BAKARANGAN', 'Kecamatan Bakarangan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN BAKARANGAN', 'mbie.oby@gmail.com'),
('KEC.BINUANG', 'Kecamatan Binuang', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN BINUANG', 'mbie.oby@gmail.com'),
('KEC.BUNGUR', 'Kecamatan Bungur', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN BUNGUR', 'mbie.oby@gmail.com'),
('KEC.CLS', 'Kecamatan Candi Laras Selatan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN CANDI LARAS SELATAN', 'mbie.oby@gmail.com'),
('KEC.CLU', 'Kecamatan Candi Laras Utara', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN CANDI LARAS UTARA', 'mbie.oby@gmail.com'),
('KEC.HATUNGUN', 'Kecamatan Hatungun', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN HATUNGUN', 'mbie.oby@gmail.com'),
('KEC.LOKPAIKAT', 'Kecamatan Lokpaikat', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN LOKPAIKAT', 'mbie.oby@gmail.com'),
('KEC.PIANI', 'Kecamatan Piani', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN PIANI', 'mbie.oby@gmail.com'),
('KEC.SALBA', 'Kecamatan Salam Babaris', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN SALAM BABARIS', 'mbie.oby@gmail.com'),
('KEC.TAPSEL', 'Kecamatan Tapin Selatan', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN TAPIN SELATAN', 'mbie.oby@gmail.com'),
('KEC.TAPTENG', 'Kecamatan Tapin Tengah', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN TAPIN TENGAH', 'mbie.oby@gmail.com'),
('KEC.TAPUT', 'Kecamatan Tapin Utara', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'KECAMATAN TAPIN UTARA', 'mbie.oby@gmail.com'),
('KESBANGPOL', 'Kantor Kesatuan Bangsa dan Politik', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'BADAN KESATUAN BANGSA DAN POLITIK', 'mbie.oby@gmail.com'),
('PBJ', 'Kantor Layanan Pengadaan Barang/Jasa Pemerintah', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', NULL, 'mbie.oby@gmail.com'),
('pertanian 2', 'Dinas Pertanian', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PERTANIAN', 'mbie.oby@gmail.com'),
('pimpinan', 'Pimpinan', '$2y$10$uu98SEUvvnFU./Fb6GATgOua6Re7CNF4LJQ7vq3s4o1gMk7Fqn2U.', 'pimpinan', 'PIMPINAN', 'pimpinan@email.com'),
('PUPR', 'Dinas Pekerjaan Umum Dan Penataan Ruang', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'DINAS PEKERJAAN UMUM DAN PENATAAN RUANG', 'mbie.oby@gmail.com'),
('rsudds', 'Rumah Sakit Umum Daerah Datu Sanggul', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'RUMAH SAKIT UMUM DAERAH DATU SANGGUL', 'mbie.oby@gmail.com'),
('SATPOLPP', 'Satuan Polisi Pamong Praja Dan Kebakaran', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'SATUAN POLISI PAMONG PRAJA DAN KEBAKARAN', 'mbie.oby@gmail.com'),
('SETDA', 'Sekretariat Daerah', '$2y$10$eK/Ru2Pm.obCeDpfHu1G..BQziBxvNY4Xqh8mX3t9xh4Kp.NpKtWK', 'skpd', 'SEKRETARIAT DAERAH', 'mbie.oby@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ajuan_usul_berkala`
--
ALTER TABLE `ajuan_usul_berkala`
  ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `berkas_ajuan_usul_berkala`
--
ALTER TABLE `berkas_ajuan_usul_berkala`
  ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `data_pegawai`
--
ALTER TABLE `data_pegawai`
  ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `notifikasi_naik_gaji`
--
ALTER TABLE `notifikasi_naik_gaji`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifikasi_pensiun`
--
ALTER TABLE `notifikasi_pensiun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifikasi_usul_berkala`
--
ALTER TABLE `notifikasi_usul_berkala`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `proses_usul_berkala`
--
ALTER TABLE `proses_usul_berkala`
  ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `riwayat_usul_berkala`
--
ALTER TABLE `riwayat_usul_berkala`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nip` (`nip`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_gajih`
--
ALTER TABLE `table_gajih`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_pangkat`
--
ALTER TABLE `table_pangkat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nip` (`nip`);

--
-- Indexes for table `table_pensiun`
--
ALTER TABLE `table_pensiun`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nip` (`nip`);

--
-- Indexes for table `verifikator_berkala`
--
ALTER TABLE `verifikator_berkala`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notifikasi_naik_gaji`
--
ALTER TABLE `notifikasi_naik_gaji`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifikasi_pensiun`
--
ALTER TABLE `notifikasi_pensiun`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifikasi_usul_berkala`
--
ALTER TABLE `notifikasi_usul_berkala`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `riwayat_usul_berkala`
--
ALTER TABLE `riwayat_usul_berkala`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `table_gajih`
--
ALTER TABLE `table_gajih`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=273;

--
-- AUTO_INCREMENT for table `table_pangkat`
--
ALTER TABLE `table_pangkat`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `table_pensiun`
--
ALTER TABLE `table_pensiun`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ajuan_usul_berkala`
--
ALTER TABLE `ajuan_usul_berkala`
  ADD CONSTRAINT `ajuan_usul_berkala_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `data_pegawai` (`nip`);

--
-- Constraints for table `proses_usul_berkala`
--
ALTER TABLE `proses_usul_berkala`
  ADD CONSTRAINT `proses_usul_berkala_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `data_pegawai` (`nip`);

--
-- Constraints for table `riwayat_usul_berkala`
--
ALTER TABLE `riwayat_usul_berkala`
  ADD CONSTRAINT `riwayat_usul_berkala_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `data_pegawai` (`nip`);

--
-- Constraints for table `table_pangkat`
--
ALTER TABLE `table_pangkat`
  ADD CONSTRAINT `table_pangkat_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `data_pegawai` (`nip`);

--
-- Constraints for table `table_pensiun`
--
ALTER TABLE `table_pensiun`
  ADD CONSTRAINT `table_pensiun_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `data_pegawai` (`nip`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
